﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FrutaControl : MonoBehaviour {

    public int pos;
    private bool subiendo = true;
    public Vector2 initialPosition;

	//La fruta se destruye a los 10 segundos de aparecer.
	void Start () {

        Invoke("autodestruccion", 10);        
	}
	
	//Animación de subir y bajar.
	void Update () {		
        if(subiendo == true)
        {
            transform.position = new Vector2(transform.position.x, transform.position.y + 0.005f);
            if (transform.position.y > initialPosition.y + 1)
            {
                subiendo = false;
            }
        }
        else
        {
            transform.position = new Vector2(transform.position.x, transform.position.y - 0.005f);
            if (transform.position.y <= initialPosition.y)
            {
                subiendo = true;
            }
        }
	}

    //Deja libre la posición en la que está y se destruye.
    void autodestruccion()
    {
        GameObject.FindGameObjectWithTag("MainCamera").GetComponent<SceneController>().frutas[pos] = false;
        Destroy(this.gameObject);        
    }

    //Cuando el personaje recoge la fruta suma los puntos, deja libre la posición en la que está y se destruye.
    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.name == "Tarzan")
        {
            GameObject.FindGameObjectWithTag("MainCamera").GetComponent<SceneController>().sumaPuntos();
            autodestruccion();            
        }
    }
}
