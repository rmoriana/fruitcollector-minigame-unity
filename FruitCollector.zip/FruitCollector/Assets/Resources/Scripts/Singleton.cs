﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Singleton { 
    
	public static int finalScore=0;//Guarda la puntuación final para mostrarla en el Game Over.
}
