﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TarzanController : MonoBehaviour {

	//Gestión del movimiento, salto y animaciones.
	void Update () {
		
        if(Input.GetKey(KeyCode.RightArrow) && transform.position.x <= 5.7f)
        {
            GetComponent<Animator>().SetBool("isWalking", true);
            transform.localScale = new Vector2(-3, 3);
            transform.position = new Vector2(transform.position.x + 0.15f, transform.position.y);
        }
        else if (Input.GetKey(KeyCode.LeftArrow) && transform.position.x >= -5.7f)
        {
            transform.localScale = new Vector2(3, 3);
            GetComponent<Animator>().SetBool("isWalking", true);
            transform.position = new Vector2(transform.position.x - 0.15f, transform.position.y);
        }
        else
        {
            GetComponent<Animator>().SetBool("isWalking", false);
        }

        if (Input.GetKeyDown(KeyCode.Space) && GetComponent<Animator>().GetBool("isJumping") == false)
        {
            GetComponent<Animator>().SetBool("isJumping", true);
            GetComponent<Rigidbody2D>().AddForce(new Vector2(0, 800));
        }

        if (GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).normalizedTime > 1 && !GetComponent<Animator>().IsInTransition(0) && GetComponent<Animator>().GetBool("isDeath") == true && GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("Death"))
        {
            SceneManager.LoadScene("GameOver");
        }

    }

    //Gestión de animaciones y eventos.
    void OnCollisionEnter2D(Collision2D other)
    {

        if(other.gameObject.name == "sueloTemporal")
        {
            Singleton.finalScore = GameObject.Find("Main Camera").GetComponent<SceneController>().puntuacion;
            GetComponent<Animator>().SetBool("isDeath", true);
            GetComponent<Rigidbody2D>().AddForce(new Vector2(0, 1000));
        }
        if(other.gameObject.tag != "fruta" && other.gameObject.transform.position.y - transform.position.y < 0 && other.gameObject.name != "sueloTemporal")
        {            
            GetComponent<Animator>().SetBool("isJumping", false);
        }
        if(other.gameObject.tag == "plataformaDestruct")
        {
            Destroy(other.gameObject, 1);
        }
    }

    
}
