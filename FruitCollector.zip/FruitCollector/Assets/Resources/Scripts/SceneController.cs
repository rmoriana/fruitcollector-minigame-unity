﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SceneController : MonoBehaviour {

    public bool[] frutas = { false, false, false, false, false, false }; //Posiciones en las que puede haber una fruta.
    float[] posFrutas = { -5.43f, 3.47f, -5.43f, 0.4f, -5.43f, -2.5f, 5.43f, 3.47f, 5.43f, 0.4f, 5.43f, -2.5f }; //Forma cutre de guardar la posición de aparición de una fruta.
    float[] platformPosX = {-2.64f,0,2.64f }; //Posiciones X en las que puede aparecer una plataforma.
    public int puntuacion=0;
    
    //Inicia la creación automática de plataformas y frutas.
    void Start () {
        InvokeRepeating("creaPlataformas", 0.5f, 3);
        InvokeRepeating("creaFruta", 1, 4);
	}
	
	//Actualiza el texto de puntuación.
	void Update () {
        GameObject.Find("Puntuacion").GetComponent<Text>().text = puntuacion.ToString();
	}

    //Se encarga de crear una nueva plataforma.
    void creaPlataformas()
    {
        int posX = Random.Range(0, 3);
        int type = Random.Range(1, 3);
        GameObject plataforma = Instantiate(Resources.Load("Prefabs/platMovil"+type), new Vector2(platformPosX[posX], 5.5f), new Quaternion(0, 0, 0, 0)) as GameObject;
        if(type == 1)
        {
            plataforma.GetComponent<PlataformaController>().destruible = true;
        }
    }

    //Se encarga de gestionar la creación de una nueva fruta en una posición disponible.
    public void creaFruta()
    {
        bool frutaPuesta = false;
            do
            {
                int pos = Random.Range(0, 6);
                if (frutas[pos] == false)
                {
                    frutaPuesta = true;
                    frutas[pos] = true;
                    GameObject fruta = Instantiate(Resources.Load("Prefabs/fruta"), new Vector2(posFrutas[pos * 2], posFrutas[pos * 2 + 1]), new Quaternion(0, 0, 0, 0)) as GameObject;
                    fruta.GetComponent<Animator>().SetInteger("typeFruta", Random.Range(0, 7));
                    fruta.GetComponent<FrutaControl>().pos = pos;
                    fruta.GetComponent<FrutaControl>().initialPosition = new Vector2(fruta.transform.position.x, fruta.transform.position.y);
                }
            } while (frutaPuesta == false);          
    }

    //Para sumar puntos desde cualquier parte del código.
    public void sumaPuntos()
    {
        puntuacion += 100;
    }
}
