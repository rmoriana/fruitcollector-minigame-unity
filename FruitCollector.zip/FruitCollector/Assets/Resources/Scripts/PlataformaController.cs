﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlataformaController : MonoBehaviour {

    public bool destruible;
    float velocidad;
   
	void Start () {
        velocidad = Random.Range(0.01f, 0.05f);        
	}
	
    //Cuando está debajo de la pantalla se destruye.
	void Update () {
		if(transform.position.y < -5.5f)
        {
            Destroy(this.gameObject);
        }
        else
        {
            transform.position = new Vector2(transform.position.x, transform.position.y - velocidad);
        }
	}
}
