﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ButtonController : MonoBehaviour {

	//Rellena un campo de texto con la puntuación final.
	void Start () {
        GameObject.Find("ScoreTxt").GetComponent<Text>().text = "Puntuacion final \n" + Singleton.finalScore;
	}
	
    //Botón para empezar otra partida.
    public void vuelveJugar()
    {
        SceneManager.LoadScene("Game");
    }
}
